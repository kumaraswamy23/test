package com.docasap.repository;
import org.springframework.data.repository.CrudRepository;

import com.docasap.model.Employee;

public interface StudentRepository extends CrudRepository<Employee, Integer>
{
}
