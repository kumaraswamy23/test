ALTER TABLE employee ADD dept VARCHAR(25);

