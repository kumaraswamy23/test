INSERT INTO employee VALUES (3, 'Rameshdg', 'test22'); 
INSERT INTO employee VALUES (4, 'Ramesh', 'test'); 